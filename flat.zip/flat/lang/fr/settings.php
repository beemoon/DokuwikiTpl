<?php
$lang['enableAccordion']   = 'Activer le menu Accordion JQuery dans la sidebar (version Desktop)';
$lang['topSidebar']   = 'Nom du panneau latéral supérieur (si le modèle supporte cette fonctionnalité). Laisser le champ vide désactive le panneau latéral supérieur.';
$lang['bottomSidebar']   = 'Nom du panneau latéral inférieur (si le modèle supporte cette fonctionnalité). Laisser le champ vide désactive le panneau latéral inférieur.';
